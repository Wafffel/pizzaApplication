package pl.krzysztof.pizzaapplication.remote.rest.dto;

public enum SizeType {
    S, M, L
}
